package CM;

public class Buku23 {
    String kodeBuku, judul;
    int tahunTerbit;

    Buku23(String kodeBuku, String judul, int tahunTerbit) {
        this.kodeBuku = kodeBuku;
        this.judul = judul;
        this.tahunTerbit = tahunTerbit;
    }

    void tampilBuku() {
        System.out.println("Kode Buku: " + kodeBuku + " | Judul: " + judul + " | Tahun Terbit: " + tahunTerbit);
    }
}
