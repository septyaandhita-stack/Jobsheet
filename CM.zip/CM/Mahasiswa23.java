package CM;

public class Mahasiswa23 {
    String nim, nama, prodi;

    Mahasiswa23(String NIM, String Nama, String Prodi) {
        this.nim = NIM;
        this.nama = Nama;
        this.prodi = Prodi;
    }

    void tampilMahasiswa() {
        System.out.println("NIM: " + nim + " | Nama:  " + nama + " | Prodi: " + prodi);
    }
}